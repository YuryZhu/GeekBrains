package ru.yzhiharevich.geekb;

public class Boy extends Members {
    public Boy(String name) {
        super("Boy", name, 30, 7, 3);
    }
}
