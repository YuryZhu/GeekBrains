package ru.yzhiharevich.geekb;

public class OldLady extends Members {
    public OldLady(String name) {
        super("OldLady", name, 10, 3, 3);
    }
}
