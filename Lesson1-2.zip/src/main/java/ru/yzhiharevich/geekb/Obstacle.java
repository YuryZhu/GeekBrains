package ru.yzhiharevich.geekb;

public abstract class Obstacle {
    public abstract void doit(Competitor competitor);
}