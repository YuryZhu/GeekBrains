package ru.yzhiharevich.geekb;

public class OldMan extends Members {
    public OldMan(String name) {
        super("OldMan", name, 10, 3, 3);
    }
}
