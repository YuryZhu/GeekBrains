package ru.yzhiharevich.geekb;

public class SportsmanA1 extends Members {
    public SportsmanA1(String name) {
        super("SportsmanA1", name, 100, 30, 8);
    }
}
