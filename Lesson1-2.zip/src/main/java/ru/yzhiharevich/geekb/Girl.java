package ru.yzhiharevich.geekb;

public class Girl extends Members {
    public Girl(String name) {
        super("Girl", name, 10, 3, 3);
    }
}
