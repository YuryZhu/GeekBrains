package ru.yzhiharevich.myexceptions;

public class MySizeArrayException extends Exception{

    public MySizeArrayException(String msg) {
        super(msg);

    }
}
