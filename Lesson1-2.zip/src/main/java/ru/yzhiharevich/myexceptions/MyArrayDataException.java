package ru.yzhiharevich.myexceptions;

public class MyArrayDataException extends Exception {

    public MyArrayDataException(String msg) {
        super(msg);
    }
}
